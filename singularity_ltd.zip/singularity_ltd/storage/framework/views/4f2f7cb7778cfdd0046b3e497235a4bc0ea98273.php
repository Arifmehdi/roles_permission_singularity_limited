<div class="sidebar-wrapper" data-simplebar="true">
			<div class="sidebar-header">
				<div>
					<img src="<?php echo e(asset('assets/images/logo-icon.png')); ?>" class="logo-icon" alt="logo icon">
				</div>
				<div>
					<h4 class="logo-text">Singularity Ltd.</h4>
                   
				</div>
				<div class="toggle-icon ms-auto">
				</div>
			</div>
			<!--navigation-->
			<ul class="metismenu" id="menu">

            
				<li>
					<a href="<?php echo e(route('home')); ?>" class="has-arrow">
						<div class="parent-icon"><i class='bx bx-home-circle'></i>
						</div>
						<div class="menu-title">Dashboard</div>
					</a>
					
				</li>



            <?php if($data = Auth::user()->role == 'Super Admin'): ?>

                <li>
                    <a href="javascript:;" class="has-arrow">
                        <div class="parent-icon"><i class="bx bx-category"></i>
                        </div>
                        <div class="menu-title"> Role</div>
                    </a>
                    <ul>
                        <li> <a href="<?php echo e(route('roles.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Manage Role</a>
                        </li>
                        
                    </ul>
                </li>
            <?php endif; ?>


                
            <?php if($data = Auth::user()->role == 'Admin'): ?>
				<li>
					<a href="javascript:;" class="has-arrow">
						<div class="parent-icon"><i class="bx bx-category"></i>
						</div>
						<div class="menu-title">Manage Users</div>
					</a>
					<ul>
						<li> <a href="<?php echo e(route('users.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Users List</a>
						</li>
						
					</ul>
				</li>
          



                <li>
					<a href="javascript:;" class="has-arrow">
						<div class="parent-icon"><i class="bx bx-category"></i>
						</div>
						<div class="menu-title">Outlets</div>
					</a>
					<ul>
						<li> <a href="app-emailbox.html"><i class="bx bx-right-arrow-alt"></i>Manage Product</a>
						</li>
						
					</ul>
				</li>


                <li>
					<a href="javascript:;" class="has-arrow">
						<div class="parent-icon"><i class="bx bx-category"></i>
						</div>
						<div class="menu-title">Product</div>
					</a>
					<ul>
						<li> <a href="<?php echo e(route('products.index')); ?>"><i class="bx bx-right-arrow-alt"></i>Manage Product</a>
						</li>
						
					</ul>
				</li>
            <?php endif; ?>
				
					
			</ul>

            
			<!--end navigation-->
		</div><?php /**PATH J:\Xampp_8.1\htdocs\laravel\singularity_ltd\resources\views/dash_sidebar.blade.php ENDPATH**/ ?>